# Arlotech Outreach Intelligence — UI Rework

This package contains the revised Standard and BLACKSITE interfaces.

## What changed

- Replaced the previous standard and BLACKSITE wordmarks and favicon artwork with a single consistent geometric brand system. The login header renders one responsive wordmark at a time.
- Kept Standard mode's existing light, professional design and its current login content.
- Kept the hidden five-second fingerprint press-and-hold gesture on the login screen. There is no visible theme toggle in the authenticated application. The selected environment remains in local storage and can be changed from the login screen after signing out.
- Reworked the BLACKSITE desktop navigation into a fixed-width operational rail, removed the confusing collapse control, tightened header spacing, and retained the mobile slide-in navigation.
- Reworked the BLACKSITE command deck into its own dashboard composition with operational telemetry cards, an activity ledger, target dossier panel, and dedicated export action. Values and records come from the existing application queries.
- Applied a consistent BLACKSITE visual language to all authenticated pages: terminal typography, technical labels, hard-edged panels, green phosphor accents, compact tables, and dark form controls.
- Replaced binary-only decorative columns with changing hexadecimal streams and made the matrix field visible behind the workspace.
- Updated selected page headings and section labels to use consistent operational language in BLACKSITE while preserving Standard-mode wording.
- Kept Supabase authentication, routes, database access, and existing business operations unchanged.

## Setup

1. Keep your existing `.env` file (it is intentionally not included in this ZIP).
2. Run `npm ci`.
3. Run `npm run build`.
4. Run `npm test`.
5. Test both environments on desktop and mobile before deploying.

The fingerprint gesture is a UI shortcut, not biometric authentication. Matrix activity is decorative; actual activity panels display application records.

## Verification

The project archive was checked for ZIP integrity. A full production build and automated test run could not be completed in this environment because dependency installation could not finish (registry access timed out). Run the commands above locally before deployment.
