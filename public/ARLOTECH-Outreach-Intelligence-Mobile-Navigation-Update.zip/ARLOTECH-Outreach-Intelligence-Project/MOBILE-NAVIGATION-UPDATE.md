# Mobile Navigation Update

## What changed
- Added a fixed five-destination mobile bottom bar: Home, Prospects, Audits, Outreach, and More.
- Added a scrollable More feature directory grouping Activity/Campaigns/Replies/Follow-ups, Intelligence tools, and Settings.
- Added active-route states, accessible labels, dialog semantics, close-on-navigation behavior, and backdrop dismissal.
- Added iPhone safe-area padding, responsive spacing, reduced-motion support, and BLACKSITE theme variants.
- Kept the existing desktop sidebar and route structure in place; the bottom navigation is only shown below 768px.

## Validation
- ZIP integrity is checked after packaging.
- `npm run build` was attempted but could not complete because the local dependency installation is incomplete: TypeScript reports missing `@types/node` (`TS2688`). No successful production build is claimed.
- No database changes, deployment, or application business-logic changes were made intentionally.
