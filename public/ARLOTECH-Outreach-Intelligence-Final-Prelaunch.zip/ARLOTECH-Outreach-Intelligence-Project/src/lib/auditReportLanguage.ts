interface AuditFindingCopy {
  title: string
  whyItMatters: string
  recommendation: string
}

interface AuditFindingInput {
  id?: string | null
  audit_id?: string | null
  title?: string | null
  category?: string | null
  recommended_fix?: string | null
}

const findingCopy: Array<[RegExp, AuditFindingCopy]> = [
  [/image-aspect-ratio/i, {
    title: 'Some images may not keep their intended proportions',
    whyItMatters: 'The displayed dimensions may stretch or compress an image. This is a presentation issue and does not show that the image loads slowly.',
    recommendation: 'We recommend reviewing the displayed width, height, and styling so each image keeps its intended aspect ratio.',
  }],
  [/heading-order/i, {
    title: 'Some heading levels may be out of sequence',
    whyItMatters: 'Heading levels help organize page content and support people who navigate by headings. A skipped level does not by itself mean the business message is unclear.',
    recommendation: 'We recommend reviewing the heading hierarchy in context and arranging levels logically without changing the visual design unnecessarily.',
  }],
  [/doctype/i, {
    title: 'The page may be using a browser compatibility mode',
    whyItMatters: 'A missing or outdated document type can cause browsers to use legacy rendering rules. This check alone does not prove that a visible layout problem exists.',
    recommendation: 'We recommend checking the rendered page and using the standard HTML5 doctype where appropriate.',
  }],
  [/(?:^|[-_])list(?:[-_]|$)|(?:^|\s)list(?:$|\s)|list.*(?:element|markup|structure)/i, {
    title: 'Some page list markup may need review',
    whyItMatters: 'Correct list structure helps browsers and assistive technologies interpret grouped information. The source check does not establish that every visitor is affected.',
    recommendation: 'We recommend checking the affected list in the rendered page and using list elements only for content that is genuinely a list.',
  }],
  [/largest-contentful-paint|largest contentful paint|\blcp\b/i, {
    title: 'Main content loading time (Largest Contentful Paint, LCP)',
    whyItMatters: 'LCP measures how long the main content takes to appear. A longer time may make visitors wait before they can use the page.',
    recommendation: 'We recommend reviewing the main content and the resources needed to display it. PageSpeed lists the measured time and any related opportunities below.',
  }],
  [/total-blocking-time|total blocking time|\btbt\b/i, {
    title: 'Time the page is busy before it responds (Total Blocking Time, TBT)',
    whyItMatters: 'TBT estimates how long the page may be too busy to respond promptly while loading. This can make the website feel slow to use.',
    recommendation: 'We recommend reviewing the scripts and page work identified by Lighthouse, then checking that the page responds smoothly after any changes.',
  }],
  [/cumulative-layout-shift|cumulative layout shift|\bcls\b/i, {
    title: 'Unexpected page movement while loading (Cumulative Layout Shift, CLS)',
    whyItMatters: 'CLS measures unexpected movement as a page loads. Moving text or buttons can make it harder for visitors to read or select the right thing.',
    recommendation: 'We recommend checking the elements that move and reserving space for images, ads, or other content before they load.',
  }],
  [/render-blocking-resources|render.blocking/i, {
    title: 'Files are delaying the page from showing its content',
    whyItMatters: 'Some files must load before the page can show its content. Delays may leave visitors waiting for a blank or incomplete page.',
    recommendation: 'We recommend reviewing the listed CSS and JavaScript files and checking whether any can load later without hiding important content.',
  }],
  [/unused-javascript|reduce unused javascript/i, {
    title: 'Some JavaScript may not be needed when the page first loads',
    whyItMatters: 'JavaScript is code that adds actions to a website. Loading code that is not needed right away may make the page slower to load or respond.',
    recommendation: 'We recommend checking the listed JavaScript files to see whether unused code can be removed or loaded only when needed.',
  }],
  [/unused-css|reduce unused css/i, {
    title: 'Some styling code may not be needed on this page',
    whyItMatters: 'CSS controls how a website looks. Unneeded styling files may add to the amount visitors must download.',
    recommendation: 'We recommend checking the listed CSS files and removing styles that the page does not use, after confirming they are not needed elsewhere.',
  }],
  [/uses-optimized-images|uses-responsive-images|modern-image-formats|efficiently-encode-images|image-delivery|offscreen-images/i, {
    title: 'Website images could be prepared to load faster',
    whyItMatters: 'Large or unnecessarily heavy images can take longer to load, especially for visitors on slower connections.',
    recommendation: 'We recommend reviewing the listed images and using suitable file sizes and formats while keeping them clear. Any savings shown are estimates, not guaranteed results.',
  }],
  [/server-response-time|document-request-latency|time-to-first-byte/i, {
    title: 'The website took time to start sending the page',
    whyItMatters: 'Visitors cannot see the page until the website begins sending it. A slower response may add to the time they wait.',
    recommendation: 'We recommend asking your hosting or development team to review the response time for the listed page and check for avoidable delays.',
  }],
  [/font-display/i, {
    title: 'Text may wait for a font file before appearing',
    whyItMatters: 'If a font takes time to load, visitors may see blank or changing text while they wait.',
    recommendation: 'We recommend checking the font loading settings so text remains readable while custom fonts load.',
  }],
  [/document-title|html-title/i, {
    title: 'The page title is missing or unclear',
    whyItMatters: 'The page title helps visitors identify a page in browser tabs and can help search engines understand what the page is about.',
    recommendation: 'We recommend checking the title on the fully loaded page and adding a clear, accurate title if it is missing.',
  }],
  [/meta-description|content-meta/i, {
    title: 'A search description was not found in the inspected page HTML',
    whyItMatters: 'A meta description can help describe a page in search results, although search engines may choose different text.',
    recommendation: 'We recommend checking the fully loaded page and its search listing before adding a concise, accurate description.',
  }],
  [/is-crawlable|crawlability/i, {
    title: 'Search engines may have difficulty accessing this page',
    whyItMatters: 'If search engines cannot access a page, they may not be able to include it in search results.',
    recommendation: 'We recommend checking the page’s access settings and confirming the result in Google Search Console or the relevant search engine tools.',
  }],
  [/robots-txt|robots\.txt/i, {
    title: 'Check the website instructions for search engines (robots.txt)',
    whyItMatters: 'The robots.txt file gives search crawlers instructions about which areas to visit. Incorrect rules may limit access to pages.',
    recommendation: 'We recommend reviewing robots.txt at the website root to confirm its instructions are intentional. This audit does not confirm whether pages are indexed.',
  }],
  [/canonical/i, {
    title: 'Check which website address search engines should treat as the main one (canonical URL)',
    whyItMatters: 'A canonical URL signals which address should represent a page when similar versions exist. An incorrect setting may confuse search engines.',
    recommendation: 'We recommend confirming that the canonical URL points to the intended page and uses the correct HTTP or HTTPS address.',
  }],
  [/image-alt|image.*alt|content-alt/i, {
    title: 'Some images may need a text description for screen readers',
    whyItMatters: 'Alternative text describes meaningful images to people using screen readers. Decorative images can correctly have empty alternative text.',
    recommendation: 'We recommend reviewing each image in context and adding a short, useful description only where the image conveys information.',
  }],
  [/color-contrast/i, {
    title: 'Some text may be difficult to read against its background',
    whyItMatters: 'Low contrast can make text harder to read, particularly for people with low vision or viewing the site in bright light.',
    recommendation: 'We recommend checking the affected text and adjusting its text or background colors to improve readability.',
  }],
  [/content-h1|h1|heading/i, {
    title: 'A main page heading was not found in the inspected HTML',
    whyItMatters: 'A clear main heading helps visitors understand what a page covers. This check inspected the page HTML and may not include content added later by JavaScript.',
    recommendation: 'We recommend checking the fully loaded page before changing its heading structure, since some websites add headings after the initial HTML loads.',
  }],
]

function getFindingCopy(finding: AuditFindingInput): AuditFindingCopy | null {
  const searchText = `${finding.audit_id || ''} ${finding.id || ''} ${finding.title || ''}`
  return findingCopy.find(([pattern]) => pattern.test(searchText))?.[1] ?? null
}

export function auditFindingTitle(finding: AuditFindingInput) {
  return getFindingCopy(finding)?.title || finding.title || 'Website observation'
}

export function auditFindingEmailTopic(finding: AuditFindingInput) {
  const searchText = `${finding.audit_id || ''} ${finding.id || ''} ${finding.title || ''}`
  if (/image-aspect-ratio/i.test(searchText)) return 'natural-looking images'
  if (/heading-order/i.test(searchText)) return 'clearer page structure'
  if (/doctype/i.test(searchText)) return 'consistent browser display'
  if (/largest-contentful-paint|\blcp\b|unused-javascript|render.blocking|server-response-time|document-request-latency/i.test(searchText)) {
    return 'faster page loading'
  }
  if (/unused-css|image-delivery|optimized-images|responsive-images|modern-image-formats|offscreen-images/i.test(searchText)) {
    return /image-delivery|optimized-images|responsive-images|modern-image-formats|offscreen-images/i.test(searchText)
      ? 'faster-loading images'
      : 'simpler page styling'
  }
  if (/meta-description|content-meta|canonical|crawlable|robots\.txt/i.test(searchText)) return 'search visibility'
  if (/color-contrast|low contrast|contrast|accessibility/i.test(searchText)) return 'easier-to-read text'
  if (/content-h1|h1|heading/i.test(searchText)) return 'a clearer page heading'
  if (/cumulative-layout-shift|\bcls\b/i.test(searchText)) return 'a steadier page layout'
  if (/total-blocking-time|\btbt\b|forced-reflow/i.test(searchText)) return 'a more responsive page'
  return 'a website improvement'
}

export function auditFindingBusinessTitle(finding: AuditFindingInput) {
  const searchText = `${finding.audit_id || ''} ${finding.id || ''} ${finding.title || ''}`
  if (/image-aspect-ratio/i.test(searchText)) return 'Some images may not keep their intended proportions'
  if (/heading-order/i.test(searchText)) return 'Some heading levels may be out of sequence'
  if (/doctype/i.test(searchText)) return 'The page may be using a browser compatibility mode'
  if (/(?:^|[-_])list(?:[-_]|$)|(?:^|\s)list(?:$|\s)|list.*(?:element|markup|structure)/i.test(searchText)) return 'Some page list markup may need review'
  if (/largest-contentful-paint|\blcp\b/i.test(searchText)) return 'The main page content takes too long to appear'
  if (/total-blocking-time|\btbt\b|forced-reflow/i.test(searchText)) return 'The page may take too long to respond'
  if (/cumulative-layout-shift|\bcls\b/i.test(searchText)) return 'Page content may move while it loads'
  if (/render.blocking/i.test(searchText)) return 'Files may delay the first view of your website'
  if (/unused.javascript/i.test(searchText)) return 'Extra website features may slow down taps and clicks'
  if (/unused.css/i.test(searchText)) return 'Parts of the page may take longer to look ready'
  if (/server-response-time|document-request-latency|time-to-first-byte/i.test(searchText)) return 'The website may take too long to start loading'
  if (/document-title|html-title|meta-description|content-meta|canonical|crawlable|robots\.txt/i.test(searchText)) {
    return 'Search engines may have difficulty understanding or finding this page'
  }
  if (/color-contrast/i.test(searchText)) return 'Some text may be difficult for visitors to read'
  if (/image-alt|image.*alt|content-alt/i.test(searchText)) return 'Some visitors may not be able to understand important images'
  if (/font-display/i.test(searchText)) return 'Some text may be slow to appear'
  if (/image/i.test(searchText)) return 'Website images may take too long to appear'
  if (/content-h1|h1|heading/i.test(searchText)) return 'The page may not clearly explain what the business offers'
  if (/performance/i.test(finding.category || '')) return 'The page may feel slow or difficult to use'
  if (/seo/i.test(finding.category || '')) return 'Customers may have difficulty finding or understanding this page'
  if (/accessibility/i.test(finding.category || '')) return 'Some visitors may find this page difficult to use'
  return 'A website issue may be creating friction for visitors'
}

export function auditFindingBusinessImpact(finding: AuditFindingInput) {
  const searchText = `${finding.audit_id || ''} ${finding.id || ''} ${finding.title || ''}`
  if (/image-aspect-ratio/i.test(searchText)) {
    return 'An image that looks stretched or compressed can make product, service, or portfolio visuals harder to assess. The check does not indicate a loading delay.'
  }
  if (/heading-order/i.test(searchText)) {
    return 'Visitors who use page headings to scan or navigate content may find the structure less predictable. This does not prove that the page message itself is unclear.'
  }
  if (/doctype/i.test(searchText)) {
    return 'Legacy browser rendering rules can sometimes affect how page elements appear. A visual issue should be confirmed in the rendered page before changes are made.'
  }
  if (/(?:^|[-_])list(?:[-_]|$)|(?:^|\s)list(?:$|\s)|list.*(?:element|markup|structure)/i.test(searchText)) {
    return 'People using assistive technology may receive less useful structure when a list is marked up incorrectly. The affected content should be checked in context.'
  }
  if (/largest-contentful-paint|\blcp\b/i.test(searchText)) {
    return 'A longer wait can frustrate potential customers looking for help before they see what you offer. If the main information takes too long to appear, they may return to search results and contact a business that responds sooner.'
  }
  if (/render.blocking/i.test(searchText)) {
    return 'Some visitors may first see a blank or unfinished page while its content is being prepared. A person comparing local providers may leave before finding your services or contact details.'
  }
  if (/unused.javascript/i.test(searchText)) {
    return 'Extra page work can make taps and clicks feel delayed, especially on a phone. Someone trying to call, book, or request a quote may give up if the page does not respond when they expect it to.'
  }
  if (/unused.css/i.test(searchText)) {
    return 'If the page styling takes longer to settle, visitors may briefly see a cluttered or unfinished layout. That first impression can make a capable local business feel less dependable.'
  }
  if (/server-response-time|document-request-latency|time-to-first-byte/i.test(searchText)) {
    return 'Before any service details appear, a visitor is waiting for the website to begin loading. A long pause at that moment can send someone with an urgent need to another provider.'
  }
  if (/image-alt|image.*alt|content-alt/i.test(searchText)) {
    return 'Visitors who cannot see an image rely on its written description to understand what it shows. Without one, they may miss important service or trust information and feel less sure about contacting you.'
  }
  if (/color-contrast/i.test(searchText)) {
    return 'Text that blends into its background is harder to read on a phone or in bright light. Visitors can miss service details, opening information, or the next step for getting in touch.'
  }
  if (/accessibility/i.test(searchText)) {
    return 'Some visitors may find it harder to read or use this part of the site. If a form, service detail, or contact option is difficult to reach, a potential customer may not complete their inquiry.'
  }
  if (/font-display/i.test(searchText)) {
    return 'If words are slow to appear or keep changing, visitors must wait to understand the page. That extra effort can make it harder to quickly find your services or contact details.'
  }
  if (/image/i.test(searchText)) {
    return 'Large pictures can take longer to appear for people using mobile data or a weak connection. A visitor may leave before seeing the work, services, or customer examples that help them choose you.'
  }
  if (/total-blocking-time|\btbt\b|forced-reflow/i.test(searchText)) {
    return 'A delayed response can make a page feel unreliable, especially when someone is trying to use it on a phone. Visitors may struggle to open service details or reach the information they need before giving up.'
  }
  if (/cumulative-layout-shift|\bcls\b/i.test(searchText)) {
    return 'When text or buttons move as the page loads, visitors can lose their place or tap the wrong thing. On a phone, that can make a simple call or booking option surprisingly difficult to use.'
  }
  if (/document-title|html-title|meta-description|content-meta|canonical|crawlable|robots\.txt/i.test(searchText)) {
    return 'People searching for a nearby service may be less likely to recognize this page as the right result. A clear, relevant search listing helps them understand what you offer before they choose whom to contact.'
  }
  if (/content-h1|h1|heading/i.test(searchText)) {
    return 'A visitor should be able to tell quickly what the business does and who it serves. If the main message is unclear, someone comparing providers may leave before checking whether you can help.'
  }
  if (/performance/i.test(finding.category || '')) {
    return 'A frustrating page experience may cause potential customers to leave before they contact you.'
  }
  if (/seo/i.test(finding.category || '')) {
    return 'This may make it harder for people searching for your service to understand or find the page.'
  }
  if (/accessibility/i.test(finding.category || '')) {
    return 'Some visitors may find it harder to get the information or help they came for.'
  }
  return 'If this issue affects a key page, it may make it harder for visitors to trust your business or get in touch.'
}

export function auditFindingWhy(finding: AuditFindingInput) {
  const copy = getFindingCopy(finding)
  if (copy) return copy.whyItMatters

  const category = finding.category?.replace(/-/g, ' ')
  if (category === 'seo') {
    return 'This search-related result may affect how search engines understand or display the page. It does not by itself confirm an indexing or ranking problem.'
  }
  if (category === 'accessibility') {
    return 'This result may make the website harder for some people to use. Our assessment did not test every visitor or assistive technology.'
  }
  if (category === 'performance') {
    return 'This performance result may affect how quickly or smoothly visitors can use the page.'
  }
  return 'This result identifies something worth reviewing on the website. Its effect depends on the page and how visitors use it.'
}

export function auditFindingRecommendation(finding: AuditFindingInput) {
  const copy = getFindingCopy(finding)
  if (copy) return copy.recommendation

  const title = finding.title?.trim()
  if (finding.recommended_fix?.trim()) {
    return `We recommend reviewing “${title || 'this result'}”. A practical next step is: ${finding.recommended_fix.trim()}`
  }
  return `We recommend reviewing “${title || 'this result'}” and the related evidence before making changes.`
}

export function clientFriendlyAuditText(value: string) {
  const replacePhrase = (text: string, pattern: RegExp, replacement: string) =>
    text.replace(pattern, (_match, offset: number, source: string) => {
      const sentenceStart = offset === 0 || /[.!?]\s*$/.test(source.slice(0, offset))
      const firstLetter = sentenceStart
        ? replacement.charAt(0).toUpperCase()
        : replacement.charAt(0).toLowerCase()
      return firstLetter + replacement.slice(1)
    })

  let text = value
    .replace(/\bI['’]m\b/gi, (_match, offset, text) => /(^|[.!?]\s+)$/.test(text.slice(0, offset)) ? "We're" : "we're")
    .replace(/\bI['’]ve\b/gi, (_match, offset, text) => /(^|[.!?]\s+)$/.test(text.slice(0, offset)) ? "We've" : "we've")
    .replace(/\bI['’]ll\b/gi, (_match, offset, text) => /(^|[.!?]\s+)$/.test(text.slice(0, offset)) ? "We'll" : "we'll")
    .replace(/\bI['’]d\b/gi, (_match, offset, text) => /(^|[.!?]\s+)$/.test(text.slice(0, offset)) ? "We'd" : "we'd")
    .replace(/\bI recommend\b/gi, (_match, offset, text) => /(^|[.!?]\s+)$/.test(text.slice(0, offset)) ? 'We recommend' : 'we recommend')
    .replace(/\bI found\b/gi, (_match, offset, text) => /(^|[.!?]\s+)$/.test(text.slice(0, offset)) ? 'We found' : 'we found')
    .replace(/\bmy\b/gi, 'our')
    .replace(/\bme\b/gi, 'us')
    .replace(/\bI\b/g, (_match, offset, text) => /(^|[.!?]\s+)$/.test(text.slice(0, offset)) ? 'We' : 'we')
  text = replacePhrase(text, /Optimize image delivery/gi, 'make website images load faster')
  text = replacePhrase(text, /Reduce unused JavaScript/gi, 'remove unnecessary website code that may slow down loading')
  text = replacePhrase(text, /Eliminate render-blocking resources/gi, 'fix files that delay your website from displaying its content')
  text = replacePhrase(text, /Address forced reflows/gi, 'fix activities that can slow down how smoothly your website responds')
  text = replacePhrase(text, /Improve crawlability/gi, 'make it easier for search engines to explore your website')
  text = text
    .replace(/\bforced reflows?\b/gi, 'activities that can slow down how smoothly the website responds')
    .replace(/\boptimize image delivery\b/gi, 'make website images load faster')
    .replace(/\bunused JavaScript\b/gi, 'unnecessary website code')
    .replace(/\brender-blocking resources?\b/gi, 'files that delay the website from displaying content')
    .replace(/\bcrawlability\b/gi, 'how easily search engines can explore the website')
    .replace(
      /Lighthouse did not return valid scores for: (.+)\./i,
      'PageSpeed did not return valid scores for these areas: $1.',
    )
    .replace(
      /HTML extraction failed: .+/i,
      'We could not inspect some page details because the page HTML was unavailable.',
    )
    .replace(
      /Desktop PageSpeed failed; the primary technical scores are from the mobile run\./i,
      'We could not get a desktop PageSpeed result, so the scores shown are from the mobile check.',
    )
    .replace(
      /Only the primary page was assessed; multi-page visual review was not requested\./i,
      'Our assessment covered only the main page. We did not request a visual review of other pages.',
    )
    .replace(
      /Visual review was limited to (\d+) same-origin page\(s\) and initial-load screenshots\./i,
      'We visually reviewed $1 page(s) from the same website using screenshots from the first page load.',
    )
    .replace(
      /Sitemap and robots\.txt availability, broken links, JavaScript-rendered states, and interactive controls were not independently tested\./i,
      'We did not check sitemap or robots.txt availability, broken links, content added later by JavaScript, or interactive controls.',
    )
  return text
}
